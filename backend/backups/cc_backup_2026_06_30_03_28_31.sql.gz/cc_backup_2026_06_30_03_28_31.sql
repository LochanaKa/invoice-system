--
-- PostgreSQL database dump
--

\restrict NS3nO6F1H5Pw3CpG2EWCZbExBwtP72G9ocjDdeey7A35nf9eNHXA8ZPHnKQoxZD

-- Dumped from database version 18.4
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: appointments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.appointments (
    id integer NOT NULL,
    apo_number character varying(50) NOT NULL,
    rep_id integer NOT NULL,
    appointment_date date NOT NULL,
    delivery_method character varying(30),
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT appointments_delivery_method_check CHECK (((delivery_method)::text = ANY ((ARRAY['BY_COURIER'::character varying, 'BY_COMPANY'::character varying, 'OFFICE_PICKUP'::character varying, 'POST'::character varying, 'OTHER'::character varying])::text[])))
);


ALTER TABLE public.appointments OWNER TO postgres;

--
-- Name: appointments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.appointments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.appointments_id_seq OWNER TO postgres;

--
-- Name: appointments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.appointments_id_seq OWNED BY public.appointments.id;


--
-- Name: company_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.company_settings (
    id integer NOT NULL,
    company_name character varying(200) NOT NULL,
    address text,
    tin character varying(50),
    phone_numbers text,
    default_warranty_text text,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.company_settings OWNER TO postgres;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    tin character varying(20),
    is_vat_registered boolean DEFAULT false,
    route_id integer,
    phone character varying(30),
    address text,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    is_active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customers_id_seq OWNER TO postgres;

--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: invoice_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoice_items (
    id bigint NOT NULL,
    invoice_id bigint NOT NULL,
    line_number integer DEFAULT 1 NOT NULL,
    description character varying(300) NOT NULL,
    serial_no character varying(200),
    qty integer DEFAULT 1 NOT NULL,
    rate numeric(12,2) DEFAULT 0.00 NOT NULL,
    amount numeric(12,2) DEFAULT 0.00 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    raw_rate numeric(12,2) DEFAULT 0 NOT NULL
);


ALTER TABLE public.invoice_items OWNER TO postgres;

--
-- Name: invoice_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.invoice_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.invoice_items_id_seq OWNER TO postgres;

--
-- Name: invoice_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.invoice_items_id_seq OWNED BY public.invoice_items.id;


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoices (
    id bigint NOT NULL,
    invoice_number character varying(50) NOT NULL,
    invoice_category character varying(10) NOT NULL,
    service_type character varying(20) CONSTRAINT invoices_transaction_type_not_null NOT NULL,
    invoice_date date NOT NULL,
    customer_id integer NOT NULL,
    rep_id integer,
    appointment_id integer,
    amount numeric(12,2) DEFAULT 0.00 NOT NULL,
    vat_amount numeric(12,2) DEFAULT 0.00 NOT NULL,
    credit_balance numeric(12,2) DEFAULT 0.00 NOT NULL,
    remarks text,
    is_vat_posted boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    contact_name character varying(100),
    due_date date,
    po_number character varying(50),
    sscl_amount numeric(12,2) DEFAULT 0 CONSTRAINT invoices_ssel_amount_not_null NOT NULL,
    profit_margin_pct numeric(8,6) DEFAULT 0 NOT NULL,
    sscl_pct numeric(8,6) DEFAULT 0 CONSTRAINT invoices_ssel_pct_not_null NOT NULL,
    vat_pct numeric(8,6) DEFAULT 0 NOT NULL,
    base_subtotal numeric(12,2) DEFAULT 0 NOT NULL,
    profit_margin_amount numeric(12,2) DEFAULT 0 NOT NULL,
    grand_total numeric(12,2) DEFAULT 0 NOT NULL,
    warranty character varying(100) DEFAULT 'N/A'::character varying,
    route_id integer,
    CONSTRAINT invoices_invoice_category_check CHECK (((invoice_category)::text = ANY ((ARRAY['ALL_INC'::character varying, 'VAT'::character varying])::text[]))),
    CONSTRAINT invoices_service_type_check CHECK (((service_type)::text = ANY ((ARRAY['SALE'::character varying, 'REPAIR'::character varying])::text[])))
);


ALTER TABLE public.invoices OWNER TO postgres;

--
-- Name: invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.invoices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.invoices_id_seq OWNER TO postgres;

--
-- Name: invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.invoices_id_seq OWNED BY public.invoices.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    id bigint NOT NULL,
    invoice_id bigint NOT NULL,
    payment_method character varying(30) NOT NULL,
    amount numeric(12,2) NOT NULL,
    cheque_number character varying(50),
    bank character varying(100),
    date_of_payment date,
    reference_notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    recorded_by_rep_id integer,
    CONSTRAINT payments_payment_method_check CHECK (((payment_method)::text = ANY ((ARRAY['CASH'::character varying, 'CHEQUE'::character varying, 'BANK_TRANSFER'::character varying, 'ONLINE'::character varying, 'DEPOSIT'::character varying])::text[])))
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payments_id_seq OWNER TO postgres;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: rate_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rate_settings (
    id integer NOT NULL,
    key character varying(80) NOT NULL,
    label character varying(120) NOT NULL,
    rate numeric(8,6) NOT NULL,
    rate_type character varying(30) NOT NULL,
    description text,
    is_active boolean,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.rate_settings OWNER TO postgres;

--
-- Name: rate_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rate_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rate_settings_id_seq OWNER TO postgres;

--
-- Name: rate_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rate_settings_id_seq OWNED BY public.rate_settings.id;


--
-- Name: reps; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reps (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    code character varying(20) NOT NULL,
    phone character varying(30),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    role character varying(100)
);


ALTER TABLE public.reps OWNER TO postgres;

--
-- Name: reps_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reps_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reps_id_seq OWNER TO postgres;

--
-- Name: reps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reps_id_seq OWNED BY public.reps.id;


--
-- Name: routes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.routes (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    is_active boolean DEFAULT true
);


ALTER TABLE public.routes OWNER TO postgres;

--
-- Name: routes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.routes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.routes_id_seq OWNER TO postgres;

--
-- Name: routes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.routes_id_seq OWNED BY public.routes.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.settings (
    id integer NOT NULL,
    sscl_pct numeric(8,6) CONSTRAINT settings_ssel_pct_not_null NOT NULL,
    vat_pct numeric(8,6) NOT NULL,
    profit_margin numeric(8,6) NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.settings OWNER TO postgres;

--
-- Name: user_preferences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_preferences (
    id integer NOT NULL,
    system_id character varying(80) NOT NULL,
    dashboard_layout jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_preferences OWNER TO postgres;

--
-- Name: user_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_preferences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_preferences_id_seq OWNER TO postgres;

--
-- Name: user_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_preferences_id_seq OWNED BY public.user_preferences.id;


--
-- Name: appointments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments ALTER COLUMN id SET DEFAULT nextval('public.appointments_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: invoice_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_items ALTER COLUMN id SET DEFAULT nextval('public.invoice_items_id_seq'::regclass);


--
-- Name: invoices id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices ALTER COLUMN id SET DEFAULT nextval('public.invoices_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: rate_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rate_settings ALTER COLUMN id SET DEFAULT nextval('public.rate_settings_id_seq'::regclass);


--
-- Name: reps id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reps ALTER COLUMN id SET DEFAULT nextval('public.reps_id_seq'::regclass);


--
-- Name: routes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.routes ALTER COLUMN id SET DEFAULT nextval('public.routes_id_seq'::regclass);


--
-- Name: user_preferences id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_preferences ALTER COLUMN id SET DEFAULT nextval('public.user_preferences_id_seq'::regclass);


--
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.appointments (id, apo_number, rep_id, appointment_date, delivery_method, notes, created_at) FROM stdin;
1	2026-01-R001	2	2026-01-06	OTHER	\N	2026-06-25 07:39:04.299251
2	2026-01-R002	1	2026-01-07	OTHER	\N	2026-06-25 07:39:04.299251
3	2026-01-R005	1	2026-01-09	OTHER	\N	2026-06-25 07:39:04.299251
4	2026-01-R006	3	2026-01-10	OTHER	\N	2026-06-25 07:39:04.299251
5	2026-01-R007	2	2026-01-13	OTHER	\N	2026-06-25 07:39:04.299251
6	2026-01-R009	3	2026-01-14	OTHER	\N	2026-06-25 07:39:04.299251
7	2026-01-R011	2	2026-01-16	OTHER	\N	2026-06-25 07:39:04.299251
8	2026-01-R014	4	2026-01-17	OTHER	\N	2026-06-25 07:39:04.299251
9	2026-01-R016	2	2026-01-19	OTHER	\N	2026-06-25 07:39:04.299251
10	2026-01-R018	3	2026-01-21	OTHER	\N	2026-06-25 07:39:04.299251
11	2026-01-R020	1	2026-01-22	OTHER	\N	2026-06-25 07:39:04.299251
12	2026-01-R021	2	2026-01-23	OTHER	\N	2026-06-25 07:39:04.299251
13	2026-01-S006	1	2026-01-01	OTHER	\N	2026-06-25 07:39:04.299251
14	2026-01-S007	1	2026-01-02	OTHER	\N	2026-06-25 07:39:04.299251
15	2026-01-S013	2	2026-01-05	OTHER	\N	2026-06-25 07:39:04.299251
16	2026-01-S019	1	2026-01-06	OTHER	\N	2026-06-25 07:39:04.299251
17	2026-01-S020	1	2026-01-08	OTHER	\N	2026-06-25 07:39:04.299251
18	2026-01-S022	1	2026-01-09	OTHER	\N	2026-06-25 07:39:04.299251
19	2026-01-S026	2	2026-01-10	OTHER	\N	2026-06-25 07:39:04.299251
20	2026-01-S033	2	2026-01-12	OTHER	\N	2026-06-25 07:39:04.299251
21	2026-01-S035	2	2026-01-13	OTHER	\N	2026-06-25 07:39:04.299251
22	2026-01-S038	3	2026-01-14	OTHER	\N	2026-06-25 07:39:04.299251
23	2026-01-S044	2	2026-01-16	OTHER	\N	2026-06-25 07:39:04.299251
24	2026-01-S049	1	2026-01-17	BY_COURIER	\N	2026-06-25 07:39:04.299251
25	2026-01-S050	2	2026-01-19	OTHER	\N	2026-06-25 07:39:04.299251
26	2026-01-S051	2	2026-01-20	OTHER	\N	2026-06-25 07:39:04.299251
27	2026-01-S054	2	2026-01-21	OTHER	\N	2026-06-25 07:39:04.299251
28	2026-01-S056	2	2026-01-22	OTHER	\N	2026-06-25 07:39:04.299251
29	2026-01-S059	4	2026-01-23	OTHER	\N	2026-06-25 07:39:04.299251
30	2026-02-R002	3	2026-02-06	OTHER	\N	2026-06-25 07:39:04.299251
31	2026-02-R003	2	2026-02-09	OTHER	\N	2026-06-25 07:39:04.299251
32	2026-02-R005	4	2026-02-18	OTHER	\N	2026-06-25 07:39:04.299251
33	2026-02-R006	2	2026-02-20	OTHER	\N	2026-06-25 07:39:04.299251
34	2026-02-R007	2	2026-02-21	OTHER	\N	2026-06-25 07:39:04.299251
35	2026-02-R009	3	2026-02-23	OTHER	\N	2026-06-25 07:39:04.299251
36	2026-02-R011	3	2026-02-24	OTHER	\N	2026-06-25 07:39:04.299251
37	2026-02-R013	3	2026-02-26	OTHER	\N	2026-06-25 07:39:04.299251
38	2026-02-R014	4	2026-02-27	OTHER	\N	2026-06-25 07:39:04.299251
39	2026-02-S016	1	2026-02-02	OTHER	\N	2026-06-25 07:39:04.299251
40	2026-02-S019	3	2026-02-05	OTHER	\N	2026-06-25 07:39:04.299251
41	2026-02-S028	2	2026-02-06	OTHER	\N	2026-06-25 07:39:04.299251
42	2026-02-S029	2	2026-02-07	OTHER	\N	2026-06-25 07:39:04.299251
43	2026-02-S032	2	2026-02-09	OTHER	\N	2026-06-25 07:39:04.299251
44	2026-02-S033	2	2026-02-10	OTHER	\N	2026-06-25 07:39:04.299251
45	2026-02-S038	2	2026-02-11	OTHER	\N	2026-06-25 07:39:04.299251
46	2026-02-S040	3	2026-02-12	OTHER	\N	2026-06-25 07:39:04.299251
47	2026-02-S041	1	2026-02-13	OTHER	\N	2026-06-25 07:39:04.299251
48	2026-02-S042	1	2026-02-14	OTHER	\N	2026-06-25 07:39:04.299251
49	2026-02-S046	1	2026-02-16	OTHER	\N	2026-06-25 07:39:04.299251
50	2026-02-S049	4	2026-02-18	BY_COURIER	\N	2026-06-25 07:39:04.299251
51	2026-02-S052	1	2026-02-19	BY_COURIER	\N	2026-06-25 07:39:04.299251
52	2026-02-S058	2	2026-02-20	OTHER	\N	2026-06-25 07:39:04.299251
53	2026-02-S059	2	2026-02-21	BY_COURIER	\N	2026-06-25 07:39:04.299251
54	2026-02-S062	3	2026-02-23	OTHER	\N	2026-06-25 07:39:04.299251
55	2026-02-S063	2	2026-02-24	OTHER	\N	2026-06-25 07:39:04.299251
56	2026-02-S066	2	2026-02-25	OTHER	\N	2026-06-25 07:39:04.299251
57	2026-02-S069	2	2026-02-26	OTHER	\N	2026-06-25 07:39:04.299251
58	2026-02-S073	4	2026-02-27	OTHER	\N	2026-06-25 07:39:04.299251
59	2026-03-R002	3	2026-03-03	OTHER	\N	2026-06-25 07:39:04.299251
60	2026-03-R006	3	2026-03-04	OTHER	\N	2026-06-25 07:39:04.299251
61	2026-03-R007	2	2026-03-06	OTHER	\N	2026-06-25 07:39:04.299251
62	2026-03-R009	2	2026-03-07	OTHER	\N	2026-06-25 07:39:04.299251
63	2026-03-R010	2	2026-03-09	OTHER	\N	2026-06-25 07:39:04.299251
64	2026-03-R015	2	2026-03-11	OTHER	\N	2026-06-25 07:39:04.299251
65	2026-03-R016	1	2026-03-13	OTHER	\N	2026-06-25 07:39:04.299251
66	2026-03-R018	1	2026-03-16	OTHER	\N	2026-06-25 07:39:04.299251
67	2026-03-R019	3	2026-03-25	OTHER	\N	2026-06-25 07:39:04.299251
68	2026-03-R020	2	2026-03-31	OTHER	\N	2026-06-25 07:39:04.299251
69	2026-03-S004	3	2026-03-03	OTHER	\N	2026-06-25 07:39:04.299251
70	2026-03-S008	3	2026-03-04	OTHER	\N	2026-06-25 07:39:04.299251
71	2026-03-S011	2	2026-03-06	OTHER	\N	2026-06-25 07:39:04.299251
72	2026-03-S018	3	2026-03-07	OTHER	\N	2026-06-25 07:39:04.299251
73	2026-03-S021	2	2026-03-09	OTHER	\N	2026-06-25 07:39:04.299251
74	2026-03-S023	2	2026-03-10	OTHER	\N	2026-06-25 07:39:04.299251
75	2026-03-S028	2	2026-03-11	OTHER	\N	2026-06-25 07:39:04.299251
76	2026-03-S033	3	2026-03-12	OTHER	\N	2026-06-25 07:39:04.299251
77	2026-03-S034	1	2026-03-13	OTHER	\N	2026-06-25 07:39:04.299251
78	2026-03-S036	1	2026-03-14	OTHER	\N	2026-06-25 07:39:04.299251
79	2026-03-S040	1	2026-03-16	OTHER	\N	2026-06-25 07:39:04.299251
80	2026-03-S041	1	2026-03-17	OTHER	\N	2026-06-25 07:39:04.299251
81	2026-03-S042	1	2026-03-18	OTHER	\N	2026-06-25 07:39:04.299251
82	2026-03-S045	3	2026-03-19	OTHER	\N	2026-06-25 07:39:04.299251
83	2026-03-S048	3	2026-03-23	BY_COURIER	\N	2026-06-25 07:39:04.299251
84	2026-03-S049	2	2026-03-24	BY_COURIER	\N	2026-06-25 07:39:04.299251
85	2026-03-S050	1	2026-03-25	OTHER	\N	2026-06-25 07:39:04.299251
86	2026-03-S056	2	2026-03-30	OTHER	\N	2026-06-25 07:39:04.299251
87	2026-03-S058	2	2026-03-31	OTHER	\N	2026-06-25 07:39:04.299251
88	2026-04-R004	4	2026-04-02	OTHER	\N	2026-06-25 07:39:04.299251
89	2026-04-R007	3	2026-04-03	OTHER	\N	2026-06-25 07:39:04.299251
90	2026-04-R009	2	2026-04-06	OTHER	\N	2026-06-25 07:39:04.299251
91	2026-04-R010	2	2026-04-07	OTHER	\N	2026-06-25 07:39:04.299251
92	2026-04-R011	2	2026-04-10	OTHER	\N	2026-06-25 07:39:04.299251
93	2026-04-R013	1	2026-04-18	BY_COURIER	\N	2026-06-25 07:39:04.299251
94	2026-04-R014	1	2026-04-22	OTHER	\N	2026-06-25 07:39:04.299251
95	2026-04-R017	3	2026-04-25	OTHER	\N	2026-06-25 07:39:04.299251
96	2026-04-R020	1	2026-04-29	OTHER	\N	2026-06-25 07:39:04.299251
97	2026-04-R021	2	2026-04-30	OTHER	\N	2026-06-25 07:39:04.299251
98	2026-04-S001	1	2026-04-02	OTHER	\N	2026-06-25 07:39:04.299251
99	2026-04-S004	2	2026-04-04	OTHER	\N	2026-06-25 07:39:04.299251
100	2026-04-S006	2	2026-04-06	OTHER	\N	2026-06-25 07:39:04.299251
101	2026-04-S007	2	2026-04-07	OTHER	\N	2026-06-25 07:39:04.299251
102	2026-04-S011	2	2026-04-08	OTHER	\N	2026-06-25 07:39:04.299251
103	2026-04-S018	2	2026-04-09	OTHER	\N	2026-06-25 07:39:04.299251
104	2026-04-S025	2	2026-04-10	OTHER	\N	2026-06-25 07:39:04.299251
105	2026-04-S028	2	2026-04-17	BY_COURIER	\N	2026-06-25 07:39:04.299251
106	2026-04-S030	1	2026-04-20	OTHER	\N	2026-06-25 07:39:04.299251
107	2026-04-S035	1	2026-04-21	OTHER	\N	2026-06-25 07:39:04.299251
108	2026-04-S036	1	2026-04-22	OTHER	\N	2026-06-25 07:39:04.299251
109	2026-04-S048	1	2026-04-27	OTHER	\N	2026-06-25 07:39:04.299251
110	2026-04-S051	1	2026-04-28	OTHER	\N	2026-06-25 07:39:04.299251
111	2026-04-S061	1	2026-04-29	OTHER	\N	2026-06-25 07:39:04.299251
112	2026-04-S064	3	2026-04-30	OTHER	\N	2026-06-25 07:39:04.299251
113	2026-05-R001	3	2026-05-01	OTHER	\N	2026-06-25 07:39:04.299251
114	2026-05-R004	4	2026-05-03	OTHER	\N	2026-06-25 07:39:04.299251
115	2026-05-R008	2	2026-05-05	OTHER	\N	2026-06-25 07:39:04.299251
116	2026-05-R009	1	2026-05-06	OTHER	\N	2026-06-25 07:39:04.299251
117	2026-05-R010	4	2026-05-07	OTHER	\N	2026-06-25 07:39:04.299251
118	2026-05-R012	1	2026-05-08	OTHER	\N	2026-06-25 07:39:04.299251
119	2026-05-R014	1	2026-05-11	OTHER	\N	2026-06-25 07:39:04.299251
120	2026-05-R016	3	2026-05-12	OTHER	\N	2026-06-25 07:39:04.299251
121	2026-05-R017	4	2026-05-13	OTHER	\N	2026-06-25 07:39:04.299251
122	2026-05-R018	4	2026-05-14	OTHER	\N	2026-06-25 07:39:04.299251
123	2026-05-R020	2	2026-05-16	OTHER	\N	2026-06-25 07:39:04.299251
124	2026-05-R021	4	2026-05-19	OTHER	\N	2026-06-25 07:39:04.299251
125	2026-05-R024	3	2026-05-20	OTHER	\N	2026-06-25 07:39:04.299251
126	2026-05-R028	4	2026-05-22	OTHER	\N	2026-06-25 07:39:04.299251
127	2026-05-R029	3	2026-05-23	OTHER	\N	2026-06-25 07:39:04.299251
128	2026-05-R030	3	2026-05-25	OTHER	\N	2026-06-25 07:39:04.299251
129	2026-05-R032	4	2026-05-27	OTHER	\N	2026-06-25 07:39:04.299251
130	2026-05-R034	4	2026-05-28	OTHER	\N	2026-06-25 07:39:04.299251
131	2026-05-R037	4	2026-05-29	OTHER	\N	2026-06-25 07:39:04.299251
132	2026-05-S002	3	2026-05-01	OTHER	\N	2026-06-25 07:39:04.299251
133	2026-05-S003	2	2026-05-02	OTHER	\N	2026-06-25 07:39:04.299251
134	2026-05-S010	2	2026-05-05	OTHER	\N	2026-06-25 07:39:04.299251
135	2026-05-S015	4	2026-05-06	OTHER	\N	2026-06-25 07:39:04.299251
136	2026-05-S017	4	2026-05-07	OTHER	\N	2026-06-25 07:39:04.299251
137	2026-05-S022	1	2026-05-08	OTHER	\N	2026-06-25 07:39:04.299251
138	2026-05-S026	4	2026-05-11	OTHER	\N	2026-06-25 07:39:04.299251
139	2026-05-S031	5	2026-05-12	OTHER	\N	2026-06-25 07:39:04.299251
140	2026-05-S035	3	2026-05-13	OTHER	\N	2026-06-25 07:39:04.299251
141	2026-05-S041	2	2026-05-15	OTHER	\N	2026-06-25 07:39:04.299251
142	2026-05-S043	2	2026-05-16	OTHER	\N	2026-06-25 07:39:04.299251
143	2026-05-S044	2	2026-05-18	OTHER	\N	2026-06-25 07:39:04.299251
144	2026-05-S049	3	2026-05-19	OTHER	\N	2026-06-25 07:39:04.299251
145	2026-05-S051	3	2026-05-20	OTHER	\N	2026-06-25 07:39:04.299251
146	2026-05-S055	3	2026-05-21	OTHER	\N	2026-06-25 07:39:04.299251
147	2026-05-S058	3	2026-05-25	OTHER	\N	2026-06-25 07:39:04.299251
148	2026-05-S059	4	2026-05-26	OTHER	\N	2026-06-25 07:39:04.299251
149	2026-05-S060	2	2026-05-29	OTHER	\N	2026-06-25 07:39:04.299251
150	2026-06-R001	3	2026-06-02	OTHER	\N	2026-06-25 07:39:04.299251
151	2026-06-R002	3	2026-06-03	OTHER	\N	2026-06-25 07:39:04.299251
152	2026-06-R006	4	2026-06-04	OTHER	\N	2026-06-25 07:39:04.299251
153	2026-06-R007	4	2026-06-07	OTHER	\N	2026-06-25 07:39:04.299251
154	2026-06-R008	1	2026-06-09	OTHER	\N	2026-06-25 07:39:04.299251
155	2026-06-R010	1	2026-06-11	OTHER	\N	2026-06-25 07:39:04.299251
156	2026-06-R013	4	2026-06-12	OTHER	\N	2026-06-25 07:39:04.299251
157	2026-06-R014	3	2026-06-15	OTHER	\N	2026-06-25 07:39:04.299251
158	2026-06-R015	2	2026-06-17	OTHER	\N	2026-06-25 07:39:04.299251
159	2026-06-R016	1	2026-06-23	OTHER	\N	2026-06-25 07:39:04.299251
160	2026-06-R018	2	2026-06-24	OTHER	\N	2026-06-25 07:39:04.299251
161	2026-06-S003	1	2026-06-01	OTHER	\N	2026-06-25 07:39:04.299251
162	2026-06-S005	3	2026-06-02	OTHER	\N	2026-06-25 07:39:04.299251
163	2026-06-S006	3	2026-06-03	OTHER	\N	2026-06-25 07:39:04.299251
164	2026-06-S007	4	2026-06-04	OTHER	\N	2026-06-25 07:39:04.299251
165	2026-06-S012	1	2026-06-06	OTHER	\N	2026-06-25 07:39:04.299251
166	2026-06-S013	1	2026-06-08	OTHER	\N	2026-06-25 07:39:04.299251
167	2026-06-S015	1	2026-06-09	OTHER	\N	2026-06-25 07:39:04.299251
168	2026-06-S017	1	2026-06-10	OTHER	\N	2026-06-25 07:39:04.299251
169	2026-06-S018	1	2026-06-11	OTHER	\N	2026-06-25 07:39:04.299251
170	2026-06-S019	1	2026-06-12	OTHER	\N	2026-06-25 07:39:04.299251
171	2026-06-S020	3	2026-06-15	OTHER	\N	2026-06-25 07:39:04.299251
172	2026-06-S029	3	2026-06-16	OTHER	\N	2026-06-25 07:39:04.299251
173	2026-06-S034	2	2026-06-17	OTHER	\N	2026-06-25 07:39:04.299251
174	2026-06-S037	3	2026-06-18	OTHER	\N	2026-06-25 07:39:04.299251
175	2026-06-S039	3	2026-06-19	OTHER	\N	2026-06-25 07:39:04.299251
176	2026-06-S040	3	2026-06-20	OTHER	\N	2026-06-25 07:39:04.299251
177	2026-06-S044	1	2026-06-22	OTHER	\N	2026-06-25 07:39:04.299251
178	2026-06-S053	2	2026-06-23	OTHER	\N	2026-06-25 07:39:04.299251
179	2026-06-S061	2	2026-06-24	OTHER	\N	2026-06-25 07:39:04.299251
\.


--
-- Data for Name: company_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.company_settings (id, company_name, address, tin, phone_numbers, default_warranty_text, updated_at) FROM stdin;
1	Creative Computers	No. 95, Colombo Road, Kurunegala	783634953-7000	+94 37 22 29 181\n+94 77 57 67 070	Please submit the Original Invoice for warranty claims.\nWarranty period is one year less than 14 working days\nGood once sold are not refundable\nNo warranty Keyboard, Mouse, Speakers, Cartridges, Toners, Ribbons, Printer Heads and all consumable items.\nWarranty covers only Manufacture Defects: Software & Virus issues, Damages or defects or due to other causes such as negligence misuse improper\noperations, power fluctuation, lightening or other natural disaster. Sabotage or accidents etc are NOT included under this warranty.\nThe customer bound to protect all the serial & warranty stickers for any warranty claims. If not, no warranty claims will be issued for such items, even if the\noriginal invoice were produced.\nRepair or replacements necessitated by such causes not covered by the warranty are subject to changes for labour, time & material. Warranty replacement\nwould be provided with available technology, if identical replacement is not available.\nCreative Computers is not liable or bonds to provide any On Site Services unless specified by a Quotation / Maintenance Agreement or on the Original\nInvoice. The customer bound to carry in any items at his / hers own expenses for such warranty claims / repairs or services.\nThe customer bound with creative to pay above balance within one week.\nAll payments can be done through cash or cheques&cheques to be drawn in favor of Creative Computers. "A/C Payee Only"	2026-06-30 00:35:02.316841
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (id, name, tin, is_vat_registered, route_id, phone, address, notes, created_at, is_active) FROM stdin;
2	Agrarian Service - Paduwasnuwara	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
3	Agrarian Service - Palugaswewa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
4	Animal Production & health - Kurunegala	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
5	Animal Production & health NWP - Kurunegala	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
6	Animal Prodution & Health Department - Kurunegala	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
7	Athhuwana Senanayaka Primary School - Chilaw	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
8	C.S.I.A.P OFFICE - Kurunegla	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
9	Council Office NWP - Kurunegala	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
10	D .A . N Karawgoda - Kurunegala	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
15	Dedunu Bakers - Waduragala	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
16	Department Of Animal Production and Health ( NWP ) - Kurunegala	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
17	Distric Samurdi Office - Kurunegala	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
18	Divisional Education Office - Arachchikattuwa	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
19	Divisional Forest Office - Kurunegala	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
20	Divisional Secretariat - Bamunakotuwa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
21	Divisional Secretariat - Bingiriya	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
22	Divisional Secretariat - Galgamuwa	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
23	Divisional Secretariat - Ganewatta	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
24	Divisional Secretariat - Giribawa	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
25	Divisional Secretariat - Hingurakgoda	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
26	Divisional Secretariat - Ibbagamuwa	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
27	Divisional Secretariat - Kotawehera	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
28	Divisional Secretariat - Kuliyapitiya East	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
29	Divisional Secretariat - Kurunegala	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
30	Divisional Secretariat - Madampe	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
31	Divisional Secretariat - Mallawapitiya	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
32	Divisional Secretariat - Mawathagama	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
33	Divisional Secretariat - Naththandiya	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
34	Divisional Secretariat - Polgahawela	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
35	Divisional Secretariat - Polpithigama	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
36	Divisional Secretariat - Rideegama	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
37	Divisional Secretariat - Wariyapola	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
38	Dodangaslanda - Mr Dipani	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
39	End Customer - Kurunegala	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
40	Engineering Department - NWP	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
41	Forest Office - Maho	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
42	Gaya Invesment - Kurunegala	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
43	Gaya Investment - Kurunegala	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
44	Hameesha Agency - Kurunegala	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
45	High Cort - Puttalam	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
46	Hitmallage Sudarma She Kumara Nayaka - Ambanpola	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
47	Janana Book Shop - Gonagama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
48	Janana Mobile - Gonagama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
49	KU / Kosgolla K.V - Kosgolla	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
50	Ku / Wellawa Centarl College - Wellawa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
51	M. B.M.U.N. Balasuriya	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
52	MARS NETWORKS (PVT) LTD, NO. 164, THIMBIRIGASYAYA ROAD, COLOMBO 05	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
53	MR B.SILVA	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
54	Mahathorawa Pagnakirthi Himi - Henamulla Kurunegala	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
55	Ministry Of Co - Operative Development NWP - Kurunegala	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
56	Mr Amila - Hewapola	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
57	Mr Anura Yapa - Maeliya	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
58	Mr Anuruddh - Maduragala	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
59	Mr Anuruddh - Waduragala	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
60	Mr Ashoka - Malkaduwawa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
61	Mr Athula - Bamunugedara	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
62	Mr Chaminda - Kurunegala	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
63	Mr Chandima - Kurunegala	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
64	Mr Dasanayaka - Kurunegala	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
65	Mr Dinesh - Mawathagama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
66	Mr Ekanayaka - Kurunegala	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
67	Mr Granwil - Malkaduwawa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
68	Mr Ilham - Ibbagamuwa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
69	Mr Imalka - Uhumiya	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
70	Mr KARAWGODA - Waduragala	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
71	Mr Kanchana - Ambakote	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
72	Mr Kirialla - Polgahawela	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
73	Mr Kulawansa - Polpithigama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
74	Mr Lahiru - Polpithigama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
75	Mr Lakshan - Kurunegala	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
76	Mr Lochana - Kurunegala	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
77	Mr Madawa - Mawathagama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
78	Mr Madawala - Kurunegala	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
79	Mr Nissanka - Pannipitiya	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
80	Mr Pasindu - Kurunegala	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
81	Mr Pradip - Ibbagamuwa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
82	Mr Ranaweera - Kandulawa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
83	Mr Ranjith - Dodangaslanda	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
84	Mr Ranura - Uyandana	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
85	Mr Rathnayaka - Kurunegala	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
86	Mr Rusuri - Uyandana	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
87	Mr Sajith - Kurunegala	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
88	Mr Shiwantha - Yanthampalawa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
89	Mr Thilakarathna - Thiththawella	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
90	Mr Vijemuni - Kohilagedara	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
91	Mr Vinod Deshan - Dunakadeniya	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
92	Mr Wanninayaka - Ehetuwewa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
93	Mr Wicramasinha - Mallawapitiya	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
94	Mr Wijemuni - Kohilagedara	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
95	Mrs U.D.N Rathnayaka - Mawathagama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
96	Ms Anusha - Kurunegala	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
97	Ms Gayani - Kurunegala	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
98	Ms Heshani - Anamaduwa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
12	DIVISIONAL SECRETARIAT - POLGAHAWELA	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	f
14	DIVISIONAL SECRETRIAT - POLGAHAWELA	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	f
13	DIVISIONAL SECRETARIAT - RIDEEGAMA	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	f
99	Ms Janaka - Mawathagama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
100	Ms Kumari - Kuruwikulama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
101	Ms Piyumi - Popithigama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
102	Ms Prasanthi - Moder Waththa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
103	Ms Tharushi - Galgamuwa	\N	f	1	\N	\N	\N	2026-06-25 07:39:03.94201	t
104	Ms Wasanthi - Wilgoda	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
105	N.W.P Engineering Department - Kurunegala	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
106	Nalinda motors - Kandulawa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
107	Nika / Hal /Thennakongama Mv ,Awlegama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
108	Officenexus - Kurunegala	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
109	Patrick Pereira - Moder St,Kurunegala	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
110	Plastica International ( pvt ) ltd - Pothuwatuna	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
111	Provincial Council - Kurunegala	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
112	ROMESH MADUSHANKA - WARIYAPOLA	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
113	Regional directorate of Health Services - Kurunegala	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
114	Regional directorate of Health Services - Madampe	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
115	Rice Research and Development Institute - Batalagoda	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
116	Royal Printers - Polpithigama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
117	SAMURDHI BANK - HETTIGEDARA	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
118	SAMURDHI BANK - KATUNERIYA	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
119	SAMURDHI BANK - MADDEGAMA	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
120	SAMURDHI BANK - NARAWILA	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
121	SAMURDHI BANK - NATHTHANDIYA	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
122	SAMURDHI BANK - WATAREKA	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
123	Samasi Manpower Service - Kurunegala	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
124	Samurdh Bank - Thissawa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
125	Samurdh Bank - Wakkunuwala	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
126	Samurdhi Bank - Anamaduwa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
127	Samurdhi Bank - Arachchikattuwa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
128	Samurdhi Bank - Awulegama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
129	Samurdhi Bank - Boralessa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
130	Samurdhi Bank - Boraluwewa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
131	Samurdhi Bank - Boyagane	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
132	Samurdhi Bank - Boyagne	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
133	Samurdhi Bank - Boyawalana	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
134	Samurdhi Bank - Bulnewa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
135	Samurdhi Bank - Chilaw	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
136	Samurdhi Bank - Dambagirigama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
137	Samurdhi Bank - Dampitiya	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
138	Samurdhi Bank - Dankotuwa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
139	Samurdhi Bank - Dehikumbura	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
140	Samurdhi Bank - Delvita	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
141	Samurdhi Bank - Delwita	\N	f	3	\N	\N	\N	2026-06-25 07:39:03.94201	t
142	Samurdhi Bank - Denagmuwa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
143	Samurdhi Bank - Diwullapitiya	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
144	Samurdhi Bank - Diyathure	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
145	Samurdhi Bank - Dodangaslanda	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
146	Samurdhi Bank - Ehetuwewa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
147	Samurdhi Bank - Galmuruwa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
148	Samurdhi Bank - Gattuwana	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
149	Samurdhi Bank - Gettuwana	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
150	Samurdhi Bank - Girathalana 1	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
151	Samurdhi Bank - Girathalana I	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
152	Samurdhi Bank - Giriulla	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
153	Samurdhi Bank - Gokarella	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
154	Samurdhi Bank - Gonadeniya	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
155	Samurdhi Bank - Hammaliya	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
156	Samurdhi Bank - Hettigedara	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
157	Samurdhi Bank - Hewanpelessa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
158	Samurdhi Bank - Hindagolla	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
159	Samurdhi Bank - Hondella	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
160	Samurdhi Bank - Horombawa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
161	Samurdhi Bank - Ibbagamuwa	\N	f	2	\N	\N	\N	2026-06-25 07:39:03.94201	t
162	Samurdhi Bank - Ihakolagama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
163	Samurdhi Bank - Ihalagama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
164	Samurdhi Bank - Inigodawela	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
165	Samurdhi Bank - Kalugall	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
166	Samurdhi Bank - Kalugalla	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
167	Samurdhi Bank - Kanadeniyawala	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
168	Samurdhi Bank - Kandulawa	\N	f	2	\N	\N	\N	2026-06-25 07:39:03.94201	t
169	Samurdhi Bank - Karadagolla	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
170	Samurdhi Bank - Karandagolla	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
171	Samurdhi Bank - Karandapaththuwa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
172	Samurdhi Bank - Karuwalagaswewa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
173	Samurdhi Bank - Katuneriya	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
174	Samurdhi Bank - Katupitiya	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
175	Samurdhi Bank - Kelemulla	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
176	Samurdhi Bank - Kobeigane	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
177	Samurdhi Bank - Kokkavila	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
178	Samurdhi Bank - Kotawehera	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
179	Samurdhi Bank - Kottukachchiya	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
180	Samurdhi Bank - Kudagalgamuwa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
181	Samurdhi Bank - Kuruwikulama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
182	Samurdhi Bank - Madagalla	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
183	Samurdhi Bank - Madagama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
184	Samurdhi Bank - Madahapola	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
185	Samurdhi Bank - Madddegama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
187	Samurdhi Bank - Mahakeliya	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
188	Samurdhi Bank - Makandura	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
189	Samurdhi Bank - Malkaduwawa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
190	Samurdhi Bank - Mallawa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
191	Samurdhi Bank - Mallawapitiya	\N	f	3	\N	\N	\N	2026-06-25 07:39:03.94201	t
192	Samurdhi Bank - Mavila	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
193	Samurdhi Bank - Mawathagama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
194	Samurdhi Bank - Mawila	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
195	Samurdhi Bank - Melsiripura	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
196	Samurdhi Bank - Minuwangate	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
197	Samurdhi Bank - Munamaldeniya	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
198	Samurdhi Bank - Mundalama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
199	Samurdhi Bank - Muneshwaram	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
200	Samurdhi Bank - Nakalagmuwa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
201	Samurdhi Bank - Narakkalliya	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
202	Samurdhi Bank - Narawila	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
203	Samurdhi Bank - Naththandiya	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
204	Samurdhi Bank - Nawagaththegama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
205	Samurdhi Bank - Nikawaratiya	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
206	Samurdhi Bank - Norochcholai	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
207	Samurdhi Bank - Ogodapola	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
208	Samurdhi Bank - Palukandewa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
209	Samurdhi Bank - Piduruwella	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
210	Samurdhi Bank - Pilessa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
211	Samurdhi Bank - Polpithigama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
212	Samurdhi Bank - Polpitiya	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
213	Samurdhi Bank - Puttalam	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
214	Samurdhi Bank - Rambadagalla	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
215	Samurdhi Bank - Rambe	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
216	Samurdhi Bank - Rathmalgoda	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
217	Samurdhi Bank - Saliyaewa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
218	Samurdhi Bank - Saliyawewa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
219	Samurdhi Bank - Sangarajapura	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
220	Samurdhi Bank - Siyabalangamuwa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
221	Samurdhi Bank - Smailpuram	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
222	Samurdhi Bank - Smilepuram	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
223	Samurdhi Bank - Socity - Mundalama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
224	Samurdhi Bank - Thalagalla	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
225	Samurdhi Bank - Udappuwa	\N	f	1	\N	\N	\N	2026-06-25 07:39:03.94201	t
226	Samurdhi Bank - Uthuruyatikaha	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
227	Samurdhi Bank - Waduwawa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
228	Samurdhi Bank - Wakkunuwala	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
229	Samurdhi Bank - Walaswewa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
230	Samurdhi Bank - Walikare	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
231	Samurdhi Bank - Weerambugedara	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
232	Samurdhi Bank - Weerapokuna	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
233	Samurdhi Bank - Wellawa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
234	Samurdhi Bank - Wennappuwa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
235	Samurdhi Bank - Weralabada	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
236	Samurdhi Bank - Weuda	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
237	Samurdhi Bank - Wewagama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
238	Samurdhi Bank - Wewagedara	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
239	Samurdhi Bank - Yakwila	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
240	Samurdhi Bank - Yanthampalawa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
241	Samurdhi Bank - polpitiya	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
242	Samurdhi Bank - weerambugedara	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
243	Samurdhi Bank Head Quarters - Kuliyapitiya East	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
244	Samurdhi Bank Scociety - Mallawapitiya	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
245	Samurdhi Bank Society - Bamunaukotuwa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
246	Samurdhi Bank Society - Chilaw	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
247	Samurdhi Bank Society - Ibbagamuwa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
248	Samurdhi Bank Society - Kobeigane	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
249	Samurdhi Bank Society - Mahawewa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
250	Samurdhi Bank Society - Mundel	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
251	Samurdhi Bank Society - Nikawaratiya	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
252	Samurdhi Bank Society - Paduwasnuwara West	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
253	Samurdhi Bank Society - Polpithigama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
254	Samurdhi Bank Society - Thambaglla	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
255	Samurdhi Bank Society - Wanathawilluwa	\N	f	1	\N	\N	\N	2026-06-25 07:39:03.94201	t
256	Samurdhi Bank Society - Wariyapola	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
257	Samurdhi Bank Socity - Arachchikattuwa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
258	Samurdhi Bank Socity - Mawathagama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
259	Samurdhi Bank Socity - Mawiela	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
260	Samurdhi Bank Socity - Polpithigama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
261	Samurdhi Bank society - Horombawa	\N	f	4	\N	\N	\N	2026-06-25 07:39:03.94201	t
262	Samurdhi Community Based Bank - Ehetuwewa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
263	Samurdhi Community Based Bank - GALKULIYA	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
264	Samurdhi Community Based Bank - Galkuliya	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
265	Samurdhi Community Based Bank - Mattakotu	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
266	Samurdhi Community Based Bank - Mohoththawa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
267	Samurdhi Community Based Bank - Puttalam	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
268	Samurdhi Community Based Bank - Wanathawilluwa	\N	f	1	\N	\N	\N	2026-06-25 07:39:03.94201	t
269	Samurdhi Community Based Bank Society - Mawathagama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
270	Samurdhi Coomunity Based Bank - Madurankuliya	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
271	Samurdhi Coomunity Based Bank - Mangalaeliya	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
272	Samurdhi Coomunity Based Bank - Mundalama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
273	Samurdhi Coomunity Based Bank - Udappuwa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
274	Samurdhi Headquarters - Kobeigane	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
275	Samurdhi Headquarters - Nawagaththegama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
276	Samurdi Bank - Hammaliya	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
277	Samurdi Bank - Nakalagamuwa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
278	Sanmurdhi Bank - Gokarella	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
279	Sanurdhi Bank - Hindagolla	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
280	Smurdhi Bank - Girathalana 1	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
281	Smurdhi Bank - Wariyapola	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
282	Suhada Computer Center - Gampaha	806214027-7000	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
283	T K Rathnayaka - Maraluwawa	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
284	WELLAWA CENTRAL COLLEGE	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
285	WELLAWA CENTRAL COLLEGEV - WELLAWA	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
286	Wayamba Technology - Kurunegala	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
287	Zonal Education - Giriulla	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
288	Zonal Education Office - Maho	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
289	Zonal Education Office - Puttalam	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
291	k.a nimal wijesiri	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
292	samurdhi bank - boyagane	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
293	samurdhi bank - weerambugedara	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
1	Test	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
290	amurdhi Bank - Maddegama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	f
186	Samurdhi Bank - Maddegama	\N	f	\N	\N	\N	\N	2026-06-25 07:39:03.94201	t
294	Mr. Sujith Asanka - Nailiya	\N	f	\N	\N	\N	\N	2026-06-27 02:12:35.023	t
295	Sample Customer A	TIN-A	t	\N	\N	\N	\N	2026-06-29 21:08:58.577275	t
296	Sample Customer B	TIN-B	f	\N	\N	\N	\N	2026-06-29 21:08:58.595194	t
297	Sample Customer C	TIN-C	t	\N	\N	\N	\N	2026-06-29 21:08:58.597302	t
11	DIVISIONAL SECRETARAIT - GANEWATTA	\N	t	\N	\N	\N	\N	2026-06-25 07:39:03.94201	f
\.


--
-- Data for Name: invoice_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoice_items (id, invoice_id, line_number, description, serial_no, qty, rate, amount, created_at, raw_rate) FROM stdin;
81	653	1	SAMSUNG 10435 TONER	\N	1	8500.00	8500.00	2026-06-29 20:41:21.87598	8500.00
82	654	1	EPSON LQ 2090 RIBBON 	\N	1	4750.00	4750.00	2026-06-29 20:50:10.132156	4750.00
83	655	1	Item A (month 1)	\N	1	1523.97	1523.97	2026-06-29 21:08:58.605945	1050.00
84	655	2	Item B (month 1)	\N	2	761.99	1523.97	2026-06-29 21:08:58.605945	525.00
85	656	1	Item A (month 1)	\N	1	1523.97	1523.97	2026-06-29 21:08:58.625138	1050.00
86	656	2	Item B (month 1)	\N	2	761.99	1523.97	2026-06-29 21:08:58.625138	525.00
87	657	1	Item A (month 1)	\N	1	1260.00	1260.00	2026-06-29 21:08:58.648432	1050.00
88	657	2	Item B (month 1)	\N	2	630.00	1260.00	2026-06-29 21:08:58.648432	525.00
89	658	1	Item A (month 1)	\N	1	1260.00	1260.00	2026-06-29 21:08:58.65486	1050.00
90	658	2	Item B (month 1)	\N	2	630.00	1260.00	2026-06-29 21:08:58.65486	525.00
91	659	1	Item A (month 2)	\N	1	1596.54	1596.54	2026-06-29 21:08:58.660048	1100.00
92	659	2	Item B (month 2)	\N	2	798.27	1596.54	2026-06-29 21:08:58.660048	550.00
93	660	1	Item A (month 2)	\N	1	1596.54	1596.54	2026-06-29 21:08:58.666489	1100.00
94	660	2	Item B (month 2)	\N	2	798.27	1596.54	2026-06-29 21:08:58.666489	550.00
95	661	1	Item A (month 2)	\N	1	1320.00	1320.00	2026-06-29 21:08:58.671946	1100.00
96	661	2	Item B (month 2)	\N	2	660.00	1320.00	2026-06-29 21:08:58.671946	550.00
97	662	1	Item A (month 2)	\N	1	1320.00	1320.00	2026-06-29 21:08:58.677078	1100.00
98	662	2	Item B (month 2)	\N	2	660.00	1320.00	2026-06-29 21:08:58.677078	550.00
99	663	1	Item A (month 3)	\N	1	1669.11	1669.11	2026-06-29 21:08:58.682532	1150.00
100	663	2	Item B (month 3)	\N	2	834.56	1669.11	2026-06-29 21:08:58.682532	575.00
101	664	1	Item A (month 3)	\N	1	1669.11	1669.11	2026-06-29 21:08:58.689165	1150.00
102	664	2	Item B (month 3)	\N	2	834.56	1669.11	2026-06-29 21:08:58.689165	575.00
103	665	1	Item A (month 3)	\N	1	1380.00	1380.00	2026-06-29 21:08:58.694198	1150.00
104	665	2	Item B (month 3)	\N	2	690.00	1380.00	2026-06-29 21:08:58.694198	575.00
105	666	1	Item A (month 3)	\N	1	1380.00	1380.00	2026-06-29 21:08:58.699824	1150.00
106	666	2	Item B (month 3)	\N	2	690.00	1380.00	2026-06-29 21:08:58.699824	575.00
107	667	1	Item A (month 4)	\N	1	1741.68	1741.68	2026-06-29 21:08:58.705173	1200.00
108	667	2	Item B (month 4)	\N	2	870.84	1741.68	2026-06-29 21:08:58.705173	600.00
109	668	1	Item A (month 4)	\N	1	1741.68	1741.68	2026-06-29 21:08:58.710994	1200.00
110	668	2	Item B (month 4)	\N	2	870.84	1741.68	2026-06-29 21:08:58.710994	600.00
111	669	1	Item A (month 4)	\N	1	1440.00	1440.00	2026-06-29 21:08:58.716441	1200.00
112	669	2	Item B (month 4)	\N	2	720.00	1440.00	2026-06-29 21:08:58.716441	600.00
113	670	1	Item A (month 4)	\N	1	1440.00	1440.00	2026-06-29 21:08:58.721656	1200.00
114	670	2	Item B (month 4)	\N	2	720.00	1440.00	2026-06-29 21:08:58.721656	600.00
115	671	1	Item A (month 5)	\N	1	1814.25	1814.25	2026-06-29 21:08:58.72673	1250.00
116	671	2	Item B (month 5)	\N	2	907.13	1814.25	2026-06-29 21:08:58.72673	625.00
117	672	1	Item A (month 5)	\N	1	1814.25	1814.25	2026-06-29 21:08:58.733097	1250.00
118	672	2	Item B (month 5)	\N	2	907.13	1814.25	2026-06-29 21:08:58.733097	625.00
119	673	1	Item A (month 5)	\N	1	1500.00	1500.00	2026-06-29 21:08:58.738384	1250.00
120	673	2	Item B (month 5)	\N	2	750.00	1500.00	2026-06-29 21:08:58.738384	625.00
121	674	1	Item A (month 5)	\N	1	1500.00	1500.00	2026-06-29 21:08:58.743485	1250.00
122	674	2	Item B (month 5)	\N	2	750.00	1500.00	2026-06-29 21:08:58.743485	625.00
123	675	1	Item A (month 6)	\N	1	1886.82	1886.82	2026-06-29 21:08:58.748798	1300.00
124	675	2	Item B (month 6)	\N	2	943.41	1886.82	2026-06-29 21:08:58.748798	650.00
125	676	1	Item A (month 6)	\N	1	1886.82	1886.82	2026-06-29 21:08:58.754846	1300.00
126	676	2	Item B (month 6)	\N	2	943.41	1886.82	2026-06-29 21:08:58.754846	650.00
127	677	1	Item A (month 6)	\N	1	1560.00	1560.00	2026-06-29 21:08:58.759957	1300.00
128	677	2	Item B (month 6)	\N	2	780.00	1560.00	2026-06-29 21:08:58.759957	650.00
129	678	1	Item A (month 6)	\N	1	1560.00	1560.00	2026-06-29 21:08:58.765574	1300.00
130	678	2	Item B (month 6)	\N	2	780.00	1560.00	2026-06-29 21:08:58.765574	650.00
131	679	1	I need to have default values that i already added in settings so when i want to change i can edit it ex : the preadded route list is not visible i want to add them in route list and also want a feature to edit it or delete a route	\N	1	7257.00	7257.00	2026-06-30 00:36:37.509358	5000.00
132	680	1	Tax & Margin Rates	\N	1	8708.40	8708.40	2026-06-30 01:08:15.724407	6000.00
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoices (id, invoice_number, invoice_category, service_type, invoice_date, customer_id, rep_id, appointment_id, amount, vat_amount, credit_balance, remarks, is_vat_posted, created_at, updated_at, contact_name, due_date, po_number, sscl_amount, profit_margin_pct, sscl_pct, vat_pct, base_subtotal, profit_margin_amount, grand_total, warranty, route_id) FROM stdin;
654	2026-01-S12495	VAT	SALE	2026-01-14	23	2	\N	4750.00	855.00	5605.00	Fetched From Previous System	f	2026-06-29 20:50:10.132156	2026-06-29 20:50:10.132156	The Accountant	2026-01-21	\N	0.00	0.000000	0.000000	0.180000	4750.00	0.00	5605.00	\N	\N
653	2026-01-S12494	VAT	SALE	2026-01-13	4	2	\N	8500.00	1530.00	0.00	Fetched From Previous System	f	2026-06-29 20:41:21.87598	2026-06-29 20:41:21.87598	The Accountant	\N	\N	0.00	0.000000	0.000000	0.180000	8500.00	0.00	10030.00	\N	\N
656	CCFR-R00001	ALL_INC	REPAIR	2026-01-05	295	6	\N	2100.00	464.94	0.00	\N	f	2026-06-29 21:08:58.625138	2026-06-29 21:08:58.625138	\N	\N	\N	63.00	0.200000	0.025000	0.180000	2100.00	420.00	3047.94	\N	\N
657	2026-06-S12496	VAT	SALE	2026-01-05	295	6	\N	2100.00	464.94	0.00	\N	f	2026-06-29 21:08:58.648432	2026-06-29 21:08:58.648432	\N	\N	\N	63.00	0.200000	0.025000	0.180000	2100.00	420.00	3047.94	\N	\N
659	CCFR-S00002	ALL_INC	SALE	2026-02-05	296	7	\N	2200.00	487.08	0.00	\N	f	2026-06-29 21:08:58.660048	2026-06-29 21:08:58.660048	\N	\N	\N	66.00	0.200000	0.025000	0.180000	2200.00	440.00	3193.08	\N	\N
660	CCFR-R00002	ALL_INC	REPAIR	2026-02-05	296	7	\N	2200.00	487.08	0.00	\N	f	2026-06-29 21:08:58.666489	2026-06-29 21:08:58.666489	\N	\N	\N	66.00	0.200000	0.025000	0.180000	2200.00	440.00	3193.08	\N	\N
662	2026-06-R00002	VAT	REPAIR	2026-02-05	296	7	\N	2200.00	487.08	0.00	\N	f	2026-06-29 21:08:58.677078	2026-06-29 21:08:58.677078	\N	\N	\N	66.00	0.200000	0.025000	0.180000	2200.00	440.00	3193.08	\N	\N
663	CCFR-S00003	ALL_INC	SALE	2026-03-05	297	6	\N	2300.00	509.22	0.00	\N	f	2026-06-29 21:08:58.682532	2026-06-29 21:08:58.682532	\N	\N	\N	69.00	0.200000	0.025000	0.180000	2300.00	460.00	3338.22	\N	\N
665	2026-06-S12498	VAT	SALE	2026-03-05	297	6	\N	2300.00	509.22	0.00	\N	f	2026-06-29 21:08:58.694198	2026-06-29 21:08:58.694198	\N	\N	\N	69.00	0.200000	0.025000	0.180000	2300.00	460.00	3338.22	\N	\N
666	2026-06-R00003	VAT	REPAIR	2026-03-05	297	6	\N	2300.00	509.22	0.00	\N	f	2026-06-29 21:08:58.699824	2026-06-29 21:08:58.699824	\N	\N	\N	69.00	0.200000	0.025000	0.180000	2300.00	460.00	3338.22	\N	\N
668	CCFR-R00004	ALL_INC	REPAIR	2026-04-05	295	7	\N	2400.00	531.36	0.00	\N	f	2026-06-29 21:08:58.710994	2026-06-29 21:08:58.710994	\N	\N	\N	72.00	0.200000	0.025000	0.180000	2400.00	480.00	3483.36	\N	\N
669	2026-06-S12499	VAT	SALE	2026-04-05	295	7	\N	2400.00	531.36	0.00	\N	f	2026-06-29 21:08:58.716441	2026-06-29 21:08:58.716441	\N	\N	\N	72.00	0.200000	0.025000	0.180000	2400.00	480.00	3483.36	\N	\N
671	CCFR-S00005	ALL_INC	SALE	2026-05-05	296	6	\N	2500.00	553.50	0.00	\N	f	2026-06-29 21:08:58.72673	2026-06-29 21:08:58.72673	\N	\N	\N	75.00	0.200000	0.025000	0.180000	2500.00	500.00	3628.50	\N	\N
672	CCFR-R00005	ALL_INC	REPAIR	2026-05-05	296	6	\N	2500.00	553.50	0.00	\N	f	2026-06-29 21:08:58.733097	2026-06-29 21:08:58.733097	\N	\N	\N	75.00	0.200000	0.025000	0.180000	2500.00	500.00	3628.50	\N	\N
674	2026-06-R00005	VAT	REPAIR	2026-05-05	296	6	\N	2500.00	553.50	0.00	\N	f	2026-06-29 21:08:58.743485	2026-06-29 21:08:58.743485	\N	\N	\N	75.00	0.200000	0.025000	0.180000	2500.00	500.00	3628.50	\N	\N
675	CCFR-S00006	ALL_INC	SALE	2026-06-05	297	7	\N	2600.00	575.64	0.00	\N	f	2026-06-29 21:08:58.748798	2026-06-29 21:08:58.748798	\N	\N	\N	78.00	0.200000	0.025000	0.180000	2600.00	520.00	3773.64	\N	\N
677	2026-06-S12501	VAT	SALE	2026-06-05	297	7	\N	2600.00	575.64	0.00	\N	f	2026-06-29 21:08:58.759957	2026-06-29 21:08:58.759957	\N	\N	\N	78.00	0.200000	0.025000	0.180000	2600.00	520.00	3773.64	\N	\N
678	2026-06-R00006	VAT	REPAIR	2026-06-05	297	7	\N	2600.00	575.64	0.00	\N	f	2026-06-29 21:08:58.765574	2026-06-29 21:08:58.765574	\N	\N	\N	78.00	0.200000	0.025000	0.180000	2600.00	520.00	3773.64	\N	\N
655	CCFR-S00001	ALL_INC	SALE	2026-01-05	295	6	\N	2100.00	464.94	3047.94	\N	f	2026-06-29 21:08:58.605945	2026-06-29 21:08:58.605945	\N	\N	\N	63.00	0.200000	0.025000	0.180000	2100.00	420.00	3047.94	\N	\N
658	2026-06-R00001	VAT	REPAIR	2026-01-05	295	6	\N	2100.00	464.94	3047.94	\N	f	2026-06-29 21:08:58.65486	2026-06-29 21:08:58.65486	\N	\N	\N	63.00	0.200000	0.025000	0.180000	2100.00	420.00	3047.94	\N	\N
661	2026-06-S12497	VAT	SALE	2026-02-05	296	7	\N	2200.00	487.08	3193.08	\N	f	2026-06-29 21:08:58.671946	2026-06-29 21:08:58.671946	\N	\N	\N	66.00	0.200000	0.025000	0.180000	2200.00	440.00	3193.08	\N	\N
664	CCFR-R00003	ALL_INC	REPAIR	2026-03-05	297	6	\N	2300.00	509.22	3338.22	\N	f	2026-06-29 21:08:58.689165	2026-06-29 21:08:58.689165	\N	\N	\N	69.00	0.200000	0.025000	0.180000	2300.00	460.00	3338.22	\N	\N
667	CCFR-S00004	ALL_INC	SALE	2026-04-05	295	7	\N	2400.00	531.36	3483.36	\N	f	2026-06-29 21:08:58.705173	2026-06-29 21:08:58.705173	\N	\N	\N	72.00	0.200000	0.025000	0.180000	2400.00	480.00	3483.36	\N	\N
670	2026-06-R00004	VAT	REPAIR	2026-04-05	295	7	\N	2400.00	531.36	3483.36	\N	f	2026-06-29 21:08:58.721656	2026-06-29 21:08:58.721656	\N	\N	\N	72.00	0.200000	0.025000	0.180000	2400.00	480.00	3483.36	\N	\N
673	2026-06-S12500	VAT	SALE	2026-05-05	296	6	\N	2500.00	553.50	3628.50	\N	f	2026-06-29 21:08:58.738384	2026-06-29 21:08:58.738384	\N	\N	\N	75.00	0.200000	0.025000	0.180000	2500.00	500.00	3628.50	\N	\N
676	CCFR-R00006	ALL_INC	REPAIR	2026-06-05	297	7	\N	2600.00	575.64	3773.64	\N	f	2026-06-29 21:08:58.754846	2026-06-29 21:08:58.754846	\N	\N	\N	78.00	0.200000	0.025000	0.180000	2600.00	520.00	3773.64	\N	\N
679	CCFR-S00007	ALL_INC	SALE	2026-06-29	3	\N	\N	5000.00	1107.00	2000.00	\N	f	2026-06-30 00:36:37.509358	2026-06-30 00:36:37.509358	\N	\N	\N	150.00	0.200000	0.025000	0.180000	5000.00	1000.00	7257.00	1 Year	11
680	CCFR-S00008	ALL_INC	SALE	2026-06-29	4	1	\N	6000.00	1328.40	0.00	\N	f	2026-06-30 01:08:15.724407	2026-06-30 01:08:15.724407	\N	\N	\N	180.00	0.200000	0.025000	0.180000	6000.00	1200.00	8708.40	\N	11
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (id, invoice_id, payment_method, amount, cheque_number, bank, date_of_payment, reference_notes, created_at, recorded_by_rep_id) FROM stdin;
480	653	CHEQUE	10030.00	\N	\N	2026-03-04	\N	2026-06-29 20:51:56.048449	\N
481	679	CASH	3000.00	\N	\N	2026-06-30	\N	2026-06-30 00:58:42.220815	3
\.


--
-- Data for Name: rate_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rate_settings (id, key, label, rate, rate_type, description, is_active, created_at, updated_at) FROM stdin;
1	sscl_pct	SSCL	0.025000	tax	Social Security Contribution Levy	t	2026-06-29 23:37:41.550453	2026-06-29 23:37:41.550453
2	vat_pct	VAT	0.180000	tax	Value Added Tax	t	2026-06-29 23:37:41.550453	2026-06-29 23:37:41.550453
3	profit_margin	Profit Margin	0.200000	margin	Default item markup	t	2026-06-29 23:37:41.550453	2026-06-30 00:37:53.12653
\.


--
-- Data for Name: reps; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reps (id, name, code, phone, is_active, created_at, role) FROM stdin;
2	Asanka	CC-0001	\N	t	2026-06-25 07:37:29.6765	CEO
1	Joseph	CC-0002	\N	t	2026-06-25 07:37:29.6765	General Manager
5	Hasitha	CC-0003	\N	t	2026-06-25 07:37:29.6765	Sales Representative
3	Pramod	CC-0004	\N	t	2026-06-25 07:37:29.6765	Sales Represantative
4	Shen	CC-0005	\N	t	2026-06-25 07:37:29.6765	Sales Represantative
6	Rep One	CC-0006	0710000001	t	2026-06-29 21:08:58.599575	Sales
7	Rep Two	CC-0007	0710000002	t	2026-06-29 21:08:58.604429	Sales
\.


--
-- Data for Name: routes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.routes (id, name, created_at, is_active) FROM stdin;
1	Puttlam	2026-06-25 07:37:29.6765	t
2	Dambulla	2026-06-25 07:37:29.6765	t
3	Kandy	2026-06-25 07:37:29.6765	t
4	Chilaw	2026-06-25 07:37:29.6765	t
5	Kurunegala	2026-06-25 07:37:29.6765	t
6	Mawathagama	2026-06-25 07:37:29.6765	t
7	Giriulla	2026-06-25 07:37:29.6765	t
8	Polpithigama	2026-06-25 07:37:29.6765	t
9	Galgamuwa	2026-06-25 07:37:29.6765	t
11	Walk-In Customer	2026-06-29 21:55:39.140131	t
12	Jaffa	2026-06-29 23:52:51.445432	t
10	Other	2026-06-25 07:37:29.6765	f
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.settings (id, sscl_pct, vat_pct, profit_margin, updated_at) FROM stdin;
1	0.025000	0.180000	0.200000	2026-06-30 00:37:53.12653
\.


--
-- Data for Name: user_preferences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_preferences (id, system_id, dashboard_layout, created_at, updated_at) FROM stdin;
1	default	[{"h": 2, "i": "kpis", "w": 12, "x": 0, "y": 0, "minH": 2, "minW": 6}, {"h": 6, "i": "revenue-trend", "w": 8, "x": 0, "y": 2, "minH": 4, "minW": 5}, {"h": 3, "i": "yoy", "w": 4, "x": 8, "y": 2, "minH": 3, "minW": 3}, {"h": 5, "i": "top-customers", "w": 4, "x": 4, "y": 13, "minH": 3, "minW": 3}, {"h": 5, "i": "top-outstanding", "w": 4, "x": 0, "y": 13, "minH": 3, "minW": 3}, {"h": 5, "i": "route-performance", "w": 4, "x": 8, "y": 5, "minH": 4, "minW": 3}, {"h": 3, "i": "aging", "w": 4, "x": 8, "y": 10, "minH": 3, "minW": 3}, {"h": 5, "i": "leaderboard", "w": 8, "x": 0, "y": 8, "minH": 3, "minW": 5}, {"h": 5, "i": "recent-invoices", "w": 4, "x": 8, "y": 13, "minH": 3, "minW": 4}]	2026-06-30 01:30:25.965648	2026-06-30 02:32:36.368578
\.


--
-- Name: appointments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.appointments_id_seq', 179, true);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customers_id_seq', 297, true);


--
-- Name: invoice_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.invoice_items_id_seq', 132, true);


--
-- Name: invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.invoices_id_seq', 680, true);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payments_id_seq', 481, true);


--
-- Name: rate_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rate_settings_id_seq', 129, true);


--
-- Name: reps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reps_id_seq', 7, true);


--
-- Name: routes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.routes_id_seq', 12, true);


--
-- Name: user_preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_preferences_id_seq', 1, true);


--
-- Name: appointments appointments_apo_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_apo_number_key UNIQUE (apo_number);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: company_settings company_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_settings
    ADD CONSTRAINT company_settings_pkey PRIMARY KEY (id);


--
-- Name: customers customers_name_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_name_unique UNIQUE (name);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: invoice_items invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_invoice_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_invoice_number_key UNIQUE (invoice_number);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: rate_settings rate_settings_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rate_settings
    ADD CONSTRAINT rate_settings_key_key UNIQUE (key);


--
-- Name: rate_settings rate_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rate_settings
    ADD CONSTRAINT rate_settings_pkey PRIMARY KEY (id);


--
-- Name: reps reps_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reps
    ADD CONSTRAINT reps_code_key UNIQUE (code);


--
-- Name: reps reps_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reps
    ADD CONSTRAINT reps_pkey PRIMARY KEY (id);


--
-- Name: routes routes_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.routes
    ADD CONSTRAINT routes_name_key UNIQUE (name);


--
-- Name: routes routes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.routes
    ADD CONSTRAINT routes_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: user_preferences user_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT user_preferences_pkey PRIMARY KEY (id);


--
-- Name: user_preferences user_preferences_system_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT user_preferences_system_id_key UNIQUE (system_id);


--
-- Name: idx_customers_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_name ON public.customers USING btree (name);


--
-- Name: idx_invoices_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_invoices_category ON public.invoices USING btree (invoice_category);


--
-- Name: idx_invoices_customer; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_invoices_customer ON public.invoices USING btree (customer_id);


--
-- Name: idx_invoices_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_invoices_date ON public.invoices USING btree (invoice_date);


--
-- Name: idx_invoices_rep; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_invoices_rep ON public.invoices USING btree (rep_id);


--
-- Name: idx_invoices_route; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_invoices_route ON public.invoices USING btree (route_id);


--
-- Name: idx_items_invoice; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_items_invoice ON public.invoice_items USING btree (invoice_id);


--
-- Name: idx_payments_invoice; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payments_invoice ON public.payments USING btree (invoice_id);


--
-- Name: idx_payments_recorded_by_rep; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payments_recorded_by_rep ON public.payments USING btree (recorded_by_rep_id);


--
-- Name: appointments appointments_rep_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_rep_id_fkey FOREIGN KEY (rep_id) REFERENCES public.reps(id);


--
-- Name: customers customers_route_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_route_id_fkey FOREIGN KEY (route_id) REFERENCES public.routes(id);


--
-- Name: invoice_items invoice_items_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: invoices invoices_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id);


--
-- Name: invoices invoices_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: invoices invoices_rep_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_rep_id_fkey FOREIGN KEY (rep_id) REFERENCES public.reps(id);


--
-- Name: invoices invoices_route_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_route_id_fkey FOREIGN KEY (route_id) REFERENCES public.routes(id);


--
-- Name: payments payments_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id);


--
-- Name: payments payments_recorded_by_rep_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_recorded_by_rep_id_fkey FOREIGN KEY (recorded_by_rep_id) REFERENCES public.reps(id);


--
-- PostgreSQL database dump complete
--

\unrestrict NS3nO6F1H5Pw3CpG2EWCZbExBwtP72G9ocjDdeey7A35nf9eNHXA8ZPHnKQoxZD

